﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class HumboltBläckfisk: Seafalopod
    { 
        public void JagaFisk(Fiskstim instance)
        {
            Random rnd = new Random();

            int successrate = rnd.Next(1, 3);

            if (successrate == 1)
            {
                Gräppa(instance.Medlämmar[0]);

                Console.WriteLine($"{Art} {ID} tog fisken {instance.Medlämmar[0].ID}.");
                instance.Medlämmar.RemoveAt(0);

                Äta();
            }
            else
            {
                Console.WriteLine($"{Art} {ID} jagade fisken {instance.Medlämmar[0].ID} men den kom undan.");
            }
        }
        public void ÄndraFärg(HumboltBläckfisk dennaBläckfisk)
        {
            Random rnd = new Random();

            int alternativ = rnd.Next(1, 3);

            if(dennaBläckfisk.Färg == "Röd")
            {
                switch (alternativ)
                {
                    case 1:
                        dennaBläckfisk.Färg = "Svart";
                        break;
                    default:
                        dennaBläckfisk.Färg = "Vit";
                        break;
                }
            }
            else if(dennaBläckfisk.Färg == "Svart")
            {
                switch (alternativ)
                {
                    case 1:
                        dennaBläckfisk.Färg = "Röd";
                        break;
                    default:
                        dennaBläckfisk.Färg = "Vit";
                        break;
                }
            }
            else
            {
                switch (alternativ)
                {
                    case 1:
                        dennaBläckfisk.Färg = "Svart";
                        break;
                    default:
                        dennaBläckfisk.Färg = "Röd";
                        break;
                }
            }

            Console.WriteLine($"{Art} {ID} ändrar sin hudfärg till {Färg}");
        }
        public void Kanibalism(BläckfiskShoal instance)
        {
            Console.WriteLine($"{Art} {ID} Gräppar tag");

            Random rnd = new Random();

            int successrate = rnd.Next(1, 3);

            if (successrate == 1)
            {
                Console.WriteLine($"{Art} {ID} tog humboltbläckfisken {instance.Medlämmar[0].ID}.");
                instance.Medlämmar.RemoveAt(0);

                Äta();
            }
            else
            {
                Console.WriteLine($"{Art} {ID} jagade humboltbläckfisken {instance.Medlämmar[0].ID} men den kom undan.");
            }
        }
        public void LäggaHumboltÄgg(List<HumboltBläckfisk> Shoalet, int minID)
        {
            HumboltBläckfisk nyBläckfisk = new HumboltBläckfisk();

            nyBläckfisk.AntalArmar = 10;
            nyBläckfisk.Art = "Humboltbläckfisk";
            nyBläckfisk.Färg = "Röd";
            nyBläckfisk.ID = minID;
            nyBläckfisk.Kön = "Hona";
            nyBläckfisk.Längd = 2;
            nyBläckfisk.Läte = "plop plop";
            nyBläckfisk.Mönster = "enfärgad";
            nyBläckfisk.Vikt = 50;
            nyBläckfisk.Ålder = 0;

            Shoalet.Add(nyBläckfisk);

            Föröka();

        }
    }
}

