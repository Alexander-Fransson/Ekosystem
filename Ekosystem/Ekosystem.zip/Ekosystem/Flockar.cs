﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Flockar
    {
        public string Flocktyp { get; set; }
        public void Resatillsammans()
        {
            Console.WriteLine($"flocken {Flocktyp} reser tillsammans");
        }


    }
}
