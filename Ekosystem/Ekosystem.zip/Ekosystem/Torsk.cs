﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Torsk:Fisk
    {
        public void Plaska()
        {
            Console.WriteLine("Plask Plask");
        }
        public void LäggaTorskÄgg(List<Torsk> FiskStimmet, int minID)
        {
            Torsk NyaTorsken = new Torsk();

            NyaTorsken.Läte = "Blub";
            NyaTorsken.Längd = 1;
            NyaTorsken.Kön = "Hane";
            NyaTorsken.ID = minID;
            NyaTorsken.Mönster = "Grön med bruna prickar";
            NyaTorsken.Vikt = 2;
            NyaTorsken.Ålder = 0;
            NyaTorsken.Art = "Torsk";
            NyaTorsken.Färg = "Grönish";

            FiskStimmet.Add(NyaTorsken);

            Föröka();

        }

    }
}
