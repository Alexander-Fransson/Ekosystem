﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Fiskstim: Flockar
    {
        public List<Torsk> Medlämmar { get; set; }

        public void Synkarörelser()
        {
            string Fiskar = Medlämmar[0].Art+" ";

            for (int i = 0; i < Medlämmar.Count; i++)
            {
                Fiskar += Medlämmar[i].ID + ",";
            }
            Fiskar += " synkar sina rörelser";

            Console.WriteLine(Fiskar);
        }
    }
}
