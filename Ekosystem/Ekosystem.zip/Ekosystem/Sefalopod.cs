using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Seafalopod : Djur
    {
        public double AntalArmar { get; set; }

        public void Simma()
        {
            Console.WriteLine($"{Art} {ID} s�ger Jag kan simma, yay");
        }
        public void Spottabl�ck(Djur instance)
        {
            Console.WriteLine($"{Art} {ID} spottar bl�ck p� {instance.Art} {instance.ID}");
        }
        public void Gr�ppa(Djur instance)
        {
            Console.WriteLine($"{Art} {ID} gr�ppar tag i {instance.Art} {instance.ID}");
        }
        public void Vattenj�tt()
        {
            Console.WriteLine($"{Art} {ID} s�ger {L�te}");
        }
        public void AndasVatten()
        {
            Console.WriteLine($"{Art} {ID} Andas vatten");
        }


    }
}
