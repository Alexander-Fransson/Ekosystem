﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Fisk : Djur
    {
        public void Simma()
        {
            Console.WriteLine($"{Art} {ID} säger Jag kan simma");
        }
        public void Sidolinjeorgan()
        {
            Console.WriteLine($"{Art} {ID} säger Jag kan känna små tryckskilnader i vattnet");
        }
        public void AndasVatten()
        {
            Console.WriteLine($"{Art} {ID} säger Jag kan andas vatten");
        }
    }
}
