﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class MarinaDäggdjur : Djur
    {
        public void Komunicera()
        {
            Console.WriteLine($"{Art} {ID} säger {Läte}! som betyder Hello world");
        }
        public void AndasLuft()
        {
            Console.WriteLine($"{Art} {ID} säger jag andas luft.");
        }
        public void Uppfostra()
        {
            Console.WriteLine($"{Art} {ID} säger mina barn är väluppfostrade");
        }
    }
}
