﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ekosystem
{
    class Kaskelot:MarinaDäggdjur
    {
        public void JagaBläckfisk(BläckfiskShoal instance)
        {
            Random rnd = new Random();

            int successrate = rnd.Next(1, 3);

            if (successrate == 1)
            {
                Console.WriteLine($"{Art} {ID} tog humboltbläckfisken {instance.Medlämmar[0].ID}.");
                instance.Medlämmar.RemoveAt(0);

                Äta();
            }
            else
            {
                Console.WriteLine($"Späckhuggaren {ID} jagade humboltbläckfisken {instance.Medlämmar[0].ID} men den kom undan.");
            }
        }
        public void Klicka()
        {
            Console.WriteLine("KLICK KLICK KLICK i 230db");
        }
        public void BajsaParfym()
        {
            Console.WriteLine($"{Art} {ID} Leta efter ambegris i din lokala parfymafär");
        }
        public void FödaKaskeloter(List<Kaskelot> KaskPoden, int minID)
        {
            Kaskelot NyKaskelot = new Kaskelot();

            NyKaskelot.Läte = "KLICK! KLICK! KLICK! i 230 db";
            NyKaskelot.Längd = 15;
            NyKaskelot.Kön = "Hona";
            NyKaskelot.ID = minID;
            NyKaskelot.Mönster = "Mörkgråblå med vita fläckar runt munnen";
            NyKaskelot.Vikt = 500;
            NyKaskelot.Ålder = 0;
            NyKaskelot.Art = "Kaskelot";
            NyKaskelot.Färg = "MörkGråblå";

            KaskPoden.Add(NyKaskelot);

            Föröka();
        }

    }
}
